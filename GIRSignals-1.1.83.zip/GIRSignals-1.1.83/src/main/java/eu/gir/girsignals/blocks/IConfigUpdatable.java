package eu.gir.girsignals.blocks;

public interface IConfigUpdatable {
	
	void updateConfigValues();
	
}
