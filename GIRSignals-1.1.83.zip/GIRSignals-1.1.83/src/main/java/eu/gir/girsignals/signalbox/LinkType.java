package eu.gir.girsignals.signalbox;


public enum LinkType {
	SIGNAL, INPUT, OUTPUT;
}
